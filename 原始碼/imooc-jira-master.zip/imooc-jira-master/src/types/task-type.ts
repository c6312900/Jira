export interface TaskType {
  id: number;
  name: string;
}
