export interface Kanban {
  id: number;
  name: string;
  projectId: number;
}
